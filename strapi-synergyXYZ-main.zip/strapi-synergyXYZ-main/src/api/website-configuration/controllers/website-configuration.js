'use strict';

/**
 * website-configuration controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::website-configuration.website-configuration');
