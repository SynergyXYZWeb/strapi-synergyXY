'use strict';

/**
 * website-configuration router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::website-configuration.website-configuration');
